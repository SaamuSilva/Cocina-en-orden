# Cocina: versión con guardado local

Esta versión conserva el tablero y guarda las tareas en localStorage. No requiere
inicio de sesión, servidor de aplicación, base de datos ni servicios de Cloudflare.
La entrada independiente `static-main.tsx` utiliza el mismo tablero; las rutas del
servidor anterior no se incluyen en el paquete para hosting.

## Subir al hosting

1. Descomprime `cocina-hosting-local.zip`.
2. Sube su contenido a la carpeta pública del hosting (suele llamarse public_html
   o www). `index.html` y la carpeta `assets` deben estar juntos.
3. Abre la dirección HTTPS de tu web. También puedes alojarla en una subcarpeta.
4. Crea una tarea, cierra el navegador y vuelve a abrir la misma dirección con
   el mismo perfil: la tarea debe seguir allí.

No subas el código del proyecto ni node_modules. El ZIP ya contiene los archivos
preparados. No se ha publicado ni sustituido la versión online anterior.

## Datos

- Crear, editar, cambiar estado, reordenar y eliminar se guardan al realizar la acción.
- Los datos permanecen al cerrar el navegador y reiniciar el dispositivo.
- Son propios del navegador, perfil y dirección de la web. No se sincronizan entre dispositivos.
- Al borrar los datos de la web se pierden las tareas. En modo incógnito no se
  garantiza que permanezcan después de cerrar la sesión.
- Cambiar de dominio o entre HTTP y HTTPS crea otro almacenamiento independiente.
- No hay contraseña: quien use el mismo perfil del navegador puede ver las tareas.
- Las tareas anteriores del servidor no se importan automáticamente ni se borran.
- Si el almacenamiento falla, la aplicación muestra un error y no anuncia éxito.

## Desarrollo

Con las dependencias instaladas:

```
npm run dev:static
npm run build:static
npm test
npx tsc --project tsconfig.static.json
```

El resultado se genera en `hosting-static/`. Los comandos originales del proyecto
se conservan para la infraestructura previa; usa los terminados en `:static`
para esta versión independiente.
